package hangman;

import java.util.ArrayList;

public class printPicture {
	public printPicture (int state, String gussed, String afterChange){
		if(state==0){
			System.out.println("+---------------------------------------------------------------------------+");
			System.out.println("|   _____                                                                   |");
			System.out.println("|   |                             Cineman                                   |");
			System.out.println("|   |                                                                       |");
			System.out.println("|   |                                                                       |");
			System.out.println("|   |       "+ afterChange +"                              |");
			System.out.println("|   |                                                                       |");
			System.out.println("|  _|_____                                                                  |");
			System.out.println("   "+ gussed +"                                                                 |");
			System.out.println("+---------------------------------------------------------------------------+");
			
		}
		if(state==1){
			System.out.println("+---------------------------------------------------------------------------+");
			System.out.println("|   _____                                                                   |");
			System.out.println("|   |                             Cineman                                   |");
			System.out.println("|   |  @                                                                    |");
			System.out.println("|   |                                                                       |");
			System.out.println("|   |       "+ afterChange +"                                       |");
			System.out.println("|   |                                                                       |");
			System.out.println("|  _|_____                                                                  |");
			System.out.println("   "+ gussed +"                                                                 |");
			System.out.println("+---------------------------------------------------------------------------+");
			
		}
		if(state==2){
			System.out.println("+---------------------------------------------------------------------------+");
			System.out.println("|   _____                                                                   |");
			System.out.println("|   |                             Cineman                                   |");
			System.out.println("|   |  @                                                                    |");
			System.out.println("|   |  |                                                                    |");
			System.out.println("|   |  |    "+ afterChange +"                                      |");
			System.out.println("|   |                                                                       |");
			System.out.println("|  _|_____                                                                  |");
			System.out.println("   "+ gussed +"                                                                 |");
			System.out.println("+---------------------------------------------------------------------------+");
			
		}

		if(state==3){
			System.out.println("+---------------------------------------------------------------------------+");
			System.out.println("|   _____                                                                   |");
			System.out.println("|   |                             Cineman                                   |");
			System.out.println("|   |  @                                                                    |");
			System.out.println("|   | /|                                                                    |");
			System.out.println("|   |  |    "+ afterChange +"                                      |");
			System.out.println("|   |                                                                       |");
			System.out.println("|  _|_____                                                                  |");
			System.out.println("   "+ gussed +"                                                                 |");
			System.out.println("+---------------------------------------------------------------------------+");
		}
		if(state==4){
			System.out.println("+---------------------------------------------------------------------------+");
			System.out.println("|   _____                                                                   |");
			System.out.println("|   |                             Cineman                                   |");
			System.out.println("|   |  @                                                                    |");
			System.out.println("|   | /|\\                                                                   |");
			System.out.println("|   |  |    "+ afterChange +"                                      |");
			System.out.println("|   |                                                                       |");
			System.out.println("|  _|_____                                                                  |");
			System.out.println("   "+ gussed +"                                                                 |");
			System.out.println("+---------------------------------------------------------------------------+");
		}
		if(state==5){
			System.out.println("+---------------------------------------------------------------------------+");
			System.out.println("|   _____                                                                   |");
			System.out.println("|   |                             Cineman                                   |");
			System.out.println("|   |  @                                                                    |");
			System.out.println("|   | /|\\                                                                   |");
			System.out.println("|   |  |    "+ afterChange +"                                      |");
			System.out.println("|   | /                                                                     |");
			System.out.println("|  _|_____                                                                  |");
			System.out.println("   "+ gussed +"                                                                 |");
			System.out.println("+---------------------------------------------------------------------------+");
		}
		if(state==6){
			System.out.println("+---------------------------------------------------------------------------+");
			System.out.println("|   _____                                                                   |");
			System.out.println("|   |                             Cineman                                   |");
			System.out.println("|   |  @                                                                    |");
			System.out.println("|   | /|\\                                                                   |");
			System.out.println("|   |  |    "+ afterChange +"                                      |");
			System.out.println("|   | / \\                                                                   |");
			System.out.println("|  _|_____                                                                  |");
			System.out.println("   "+ gussed +"                                                                 |");
			System.out.println("+---------------------------------------------------------------------------+");
		}
		if(state==7){
			System.out.println("+---------------------------------------------------------------------------+");
			System.out.println("|   _____                                                                   |");
			System.out.println("|   |  |                          Cineman                                   |");
			System.out.println("|   |  @                                                                    |");
			System.out.println("|   | /|\\                                                                   |");
			System.out.println("|   |  |         "+ afterChange +"                                 |");
			System.out.println("|   | / \\                                                                   |");
			System.out.println("|  _|_____                                                                  |");
			System.out.println("   "+ gussed +"                                                                 |");
			System.out.println("+---------------------------------------------------------------------------+");
			
		}

	}
	public static void main(String[] args){
		String afterChange = "___ _____ __ _____ _______";
		String gussed = "zkyqmlnp";
		new printPicture(8, gussed, afterChange);
	}
}
