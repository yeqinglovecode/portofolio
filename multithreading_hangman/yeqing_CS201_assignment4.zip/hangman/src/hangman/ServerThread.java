package hangman;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Random;
import java.io.IOException;

public class ServerThread extends Thread {
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private hangmainServer hs;
	public String currUsername;
	public String gameName;
	public ServerThread(Socket s, hangmainServer hs){
		currUsername = "";
		gameName = "";
		try{
			this.hs = hs;
			oos  = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			this.start();
		} catch(IOException ioe){
			System.out.println("ioe: "+ioe.getMessage());
		} 
	}
	

	
	public void sendMessage(HangmanMessage message){
		try{
			oos.writeObject(message);
			oos.flush();
		} catch(IOException ioe){
			System.out.println("ioe: "+ioe.getMessage());
		}
	}
	
	public void run(){
		try{
			while(true){
				HangmanMessage message = (HangmanMessage) ois.readObject();
				int type = message.getType();
				
	
				if(type==1){
					String name = message.getContent();
					ArrayList<HangmanGame>theList = hs.getGames();
					if(theList.size()==0){
						currUsername = name;
						try{
							HangmanMessage mes = new HangmanMessage("", 2, "no username found",name, "", "", "", "", "", null, null);
							oos.writeObject(mes);
							oos.flush();
						}catch(IOException ioe){
							System.out.println("ioe: "+ioe.getMessage());
						}
					}else{
						boolean find = false;
						for(int i=0; i<theList.size(); i++){
							ArrayList<String>nameList = theList.get(i).getNameList();
							if(nameList.size()!=0)
								for(int j=0; j<nameList.size(); j++){
									if(name.equals(nameList.get(j))){
										find = true;
								}
						     }
						 }
						if(find){
							try{
								HangmanMessage mes = new HangmanMessage("", 2, "find this username", "", "", "", "", "", "", null, null);
								oos.writeObject(mes);
								oos.flush();
							}catch(IOException ioe){
								System.out.println("ioe: "+ioe.getMessage());
							}
							
						}else{
							currUsername = name;
							try{
								HangmanMessage mes = new HangmanMessage("", 2, "no username found", name, "", "", "", "", "", null, null);
								oos.writeObject(mes);
								oos.flush();
							}catch(IOException ioe){
								System.out.println("ioe: "+ioe.getMessage());
							}
							
						}
					}
				}//type 1
				if(type==3){
					String name = message.getContent();
					ArrayList<HangmanGame>theList = hs.getGames();
					//System.out.println(theList.size());
					if(theList.size()==0){
						try{
							gameName = name;
							HangmanMessage mes = new HangmanMessage("", 4, "no gamename found", name, "", "", "", "", "", null, null);
							oos.writeObject(mes);
							oos.flush();
						}catch(IOException ioe){
							System.out.println("ioe: "+ioe.getMessage());
						}
					}else {
						boolean found = false;
						for(int i=0; i<theList.size(); i++){
							if(name.equals(theList.get(i).getName())){
								found = true;
							}
						}
						if(found){
							try{
								HangmanMessage mes = new HangmanMessage("", 4, "find this gamename", name, "", "", "", "", "", null, null);
								oos.writeObject(mes);
								oos.flush();
							}catch(IOException ioe){
								System.out.println("ioe: "+ioe.getMessage());
							}
							
						}else{
							gameName = name;
							try{
								HangmanMessage mes = new HangmanMessage("", 4, "no gamename found", name, "", "", "", "", "", null, null);
								oos.writeObject(mes);
								oos.flush();
							}catch(IOException ioe){
								System.out.println("ioe: "+ioe.getMessage());
							}

						}
						
					}
					
				}//type 3
				if(type==41){
					String gameName = message.getGameName();
					String creatorName = message.getContent();
					HangmanGame hg = new HangmanGame(gameName, 1, creatorName);
					//hg.createHashMap();
					int sizeOfWordBank = hs.wordBank.size();
					Random rand = new Random();
					int randomNum = rand.nextInt(sizeOfWordBank);
					hg.setWord(hs.wordBank.get(randomNum));
				
					
					String afterE = hg.afterEncrypt;
					this.gameName = gameName;
					currUsername = creatorName;
					hs.aListOfGame.add(hg);
					System.out.println(hg.lifeRecord);
					ArrayList<location>ll = new ArrayList<location>();
					ll.add(new location(gameName, creatorName));
				
					HangmanMessage message2 = new HangmanMessage("", 42, afterE, "", "", "", "", "", "", null, null);
					
					hs.sendMessageToSomeClients(ll, message2);
					
					
				}
				if(type==5){
					//System.out.println("get info");
					String gameName = message.getGameName();
					String creatorName = message.getContent();
					String gameSize = message.getResult();
					int size = Integer.parseInt(gameSize);
					HangmanGame hg = new HangmanGame(gameName, size, creatorName);
					int sizeOfWordBank = hs.wordBank.size();
					Random rand = new Random();
					int randomNum = rand.nextInt(sizeOfWordBank);
					hg.setWord(hs.wordBank.get(randomNum));
					//hg.setWord("zxc");
					//TO DO: change to random get one from the vector of words
					this.gameName = gameName;
					currUsername = creatorName;
					hs.aListOfGame.add(hg);
					//System.out.println(hs.aListOfGame.size());
					int difference = hg.getDifference();
					//System.out.println(difference);
					try{
						//System.out.println("sent");
						HangmanMessage message2 = new HangmanMessage("", 6, Integer.toString(difference), "", "", "", "", "", "", null, null);
						oos.writeObject(message2);
						oos.flush();
					}catch(IOException ioe){
						System.out.println("ioe in creating hangman game 555555: "+ioe.getMessage());
					}
							
				}//type 5
				if(type==7){
					String gamename = message.getContent();
					if(hs.aListOfGame.size()==0){
						try{
							HangmanMessage message2 = new HangmanMessage("", 8, "error","", "", "", "", "", "", null, null);
							oos.writeObject(message2);
							oos.flush();
						}catch(IOException ioe){
							System.out.println("ioe: "+ioe.getMessage());
						}
					}else{
						boolean okay = false;
						for(int i=0; i<hs.aListOfGame.size(); i++){
							if(gamename.equals(hs.aListOfGame.get(i).getName())){
								int dif = hs.aListOfGame.get(i).getDifference();
								if(dif!=0){
									okay = true;
								}
							}
						}
						if(okay){
							gameName = gamename;
							try{
								HangmanMessage message2 = new HangmanMessage("", 8, "okay","", "", "", "", "", "", null, null);
								oos.writeObject(message2);
								oos.flush();
							}catch(IOException ioe){
								System.out.println("ioe: "+ioe.getMessage());
							}
							
						}else{
							try{
								HangmanMessage message2 = new HangmanMessage("", 8, "error","", "", "", "", "", "", null, null);
								oos.writeObject(message2);
								oos.flush();
							}catch(IOException ioe){
								System.out.println("ioe: "+ioe.getMessage());
							}
						}
					}
				}//type 7
				if(type==9){
					String gamename = message.getGameName();
					String username = message.getContent();
					boolean found = false;
					if(hs.aListOfGame.size()==0){
						try{
							HangmanMessage message2 = new HangmanMessage("", 10, "used","", "", "", "", "", "", null, null);
							oos.writeObject(message2);
							oos.flush();
						}catch(IOException ioe){
							System.out.println("ioe: "+ioe.getMessage());
						}
					}else{
						for(int i=0; i<hs.aListOfGame.size(); i++){
							if(gamename.equals(hs.aListOfGame.get(i).getName())){
								ArrayList<String>currNameList = hs.aListOfGame.get(i).getNameList();
								for(int j=0; j<currNameList.size(); j++){
									if(username.equals(currNameList.get(j))){
										found = true;
									}
								}
							}
						}
						if(found){
							try{
								HangmanMessage message2 = new HangmanMessage("", 10, "used","", "", "", "", "", "", null, null);
								oos.writeObject(message2);
								oos.flush();
							}catch(IOException ioe){
								System.out.println("ioe: "+ioe.getMessage());
							}		
						}else{
							currUsername = username;
							try{
								HangmanMessage message2 = new HangmanMessage("", 10, "okay",username, "", "", "", "", "",null, null);
								oos.writeObject(message2);
								oos.flush();
							}catch(IOException ioe){
								System.out.println("ioe : "+ioe.getMessage());
							}
							
							for(int i=0; i<hs.aListOfGame.size(); i++){
								if(gamename.equals(hs.aListOfGame.get(i).getName())){
									HangmanGame currg = hs.aListOfGame.get(i);
									currg.addPlayer(username);
									int prev = currg.getDifference();
									currg.setDifference(prev-1);
									////a player join a game
									//the creator should receive a message
									//if the game is full, all members should get a all member message
									if(prev-1==0){//when the game is full
										String gameN = currg.getName();
										ArrayList<String> candidates = currg.getNameList();
										String candi = "";
										ArrayList<location> l = new ArrayList<location>();
										for(int j=0; j<candidates.size(); j++){
											String name = candidates.get(j);
											location ll = new location(currg.getName(), name);
											l.add(ll);
											candi+=name;
											if(j!=candidates.size()-1){
												candi+=", ";
											}
										}
										currg.createHashMap();
										HangmanMessage message3 = new HangmanMessage("", 14, candi, currg.afterEncrypt, "", "", "", "", "", null, null);
										hs.sendMessageToSomeClients(l, message3);

										
										
									}else{//when the game is not full, only the creator get notified
										String creatorName = currg.getCreator();
										String gameN = currg.getName();
										location thelocation = new location (gameN, creatorName);
										ArrayList<location>thel = new ArrayList<location>();
										thel.add(thelocation);
										HangmanMessage message2 = new HangmanMessage("", 12, username, Integer.toString(currg.getDifference()), "", "", "", "", "", null, null);
										hs.sendMessageToSomeClients(thel, message2);
												
									}
									
								}
							}
						}
					}//else
				}//type9
				if(type==21){
					//System.out.println("here");
					String gussed = message.getContent();
					String gameN = message.getGameName();
					String player = message.getResult();

					for(int i=0; i<hs.aListOfGame.size(); i++){
						if(gameN.equals(hs.aListOfGame.get(i).getName())){
							HangmanGame currg = hs.aListOfGame.get(i);
							String GuessResult="";
							String GameIsOver = "";
							ArrayList<String>playerNameList = currg.getNameList();
							String winType = "";
						//	System.out.println(currg.theWord);
							int currLife = currg.getLife(player);
							if(gussed.toCharArray().length==1){//guess a character
								String theWord = currg.theWord;
								if(theWord.indexOf(gussed)>=0){
									//theWord contains the character
									//TODO update the GUI
									GuessResult = "You guessed right!";
									currg.updateAfterEncrypt(gussed);
									if(currg.GameOver){
										GameIsOver="true";
										winType = "1";//win by guessing the last character
									}else{
										GameIsOver="false";
									}
					
								}else{//theWord doesn't contain the char
									GuessResult = "You guessed wrong :(";
									currg.appendWrongGuess(gussed);
									GameIsOver = "false";
									if(currLife<7){
										currg.decreaseALife(player);
										
										currLife = currg.getLife(player);
									}
									
								}
								
							}else{//guess a phrase
								String theWord = currg.theWord;
								if(gussed.equalsIgnoreCase(theWord)){//guess right
									GuessResult = "You guessed right!";
									currg.afterEncrypt = currg.theWord;
									currg.GameOver = true;
									GameIsOver = "true";
									winType = "2";//win by directly guessing the phrase
								}else{//guess wrong
									GuessResult = "You guessed wrong :(";
									GameIsOver = "false";
									if(currLife<7){
										currg.decreaseALife(player);
										currLife = currg.getLife(player);
									}
								}
								
							}
							ArrayList<String>stillLive = new ArrayList<String>();
							if(currLife==7){
								for(int m=0; m<playerNameList.size(); m++){
									if(currg.getLife(playerNameList.get(m))<7){
										stillLive.add(playerNameList.get(m));
									}
									
								}
							}
							if(stillLive.size()==1){
								winType="3";//winByDefault
								GameIsOver = "true";
								playerNameList = stillLive;
							}
							//System.out.println(currg.lifeRecord);
							int lifeafterguess = currg.getLife(player);
							HangmanMessage hmm = new HangmanMessage(GuessResult, 24, player,gussed, currg.wrongGussedList,Integer.toString(currLife), currg.afterEncrypt, GameIsOver, winType, playerNameList, currg.lifeRecord);
							hs.sendMessageToPeopleInOneGame(currg.getName(), hmm);
					
						}
					}
					
				}//type 21
			}//while
		}catch(ClassNotFoundException cnfe){
			System.out.println("cnfe in run: "+cnfe.getMessage());
		} catch(IOException ioe){
			System.out.println("ioe in run: "+ioe.getMessage());
		}
	}
	

}
