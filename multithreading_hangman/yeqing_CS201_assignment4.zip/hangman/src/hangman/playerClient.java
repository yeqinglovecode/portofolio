package hangman;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class playerClient extends Thread{
	private static int validportname;
	private static String validipaddress;
	private ObjectInputStream ois;
	private boolean repeatedUsername = true;
	private boolean repeatedGamename = true;
	private boolean successfulcreated = false;
	private boolean foundthegame = false;
	private boolean repeatedusernameingame = true;
	private boolean validnumbersize = false;
	private boolean endGame = false;
	private boolean okToSend = true;
	private ObjectOutputStream oos;
	private String UserName;
	private String GameName;
	private String GameSize;
	private String currGameName;
	private String currLife;
	private String currentDifference;
	
	public playerClient(Socket sk){

		Scanner scanner = null;
		UserName = null;
		GameName = null;
		GameSize = null;
		currentDifference = null;
		currGameName = null;
		currLife="0";
		try{
			
			scanner = new Scanner(System.in);
			oos = new ObjectOutputStream(sk.getOutputStream());
			ois = new ObjectInputStream(sk.getInputStream());
			this.start();
	
			boolean validCommand = false;
			String finalcommand = "";
			System.out.println("Please choose from the following: ");
			System.out.println("1. Start a game");
			System.out.println("2. Join a game");
			while(!validCommand){
				String input = scanner.nextLine();
				if(isInteger(input)){
					if(Integer.parseInt(input)==1 || Integer.parseInt(input)==2){
						validCommand = true;
						finalcommand = input;
						break;
					}
				}

				System.out.println("Invalid command. Please choose from the following:");
				System.out.println("1. Start a game");
				System.out.println("2. Join a game");
				
			}
		
			if(Integer.parseInt(finalcommand)==1){
				while(repeatedUsername){
					System.out.println("Please enter your username:");
					String username = scanner.nextLine();
					
					try{
						HangmanMessage hm1 = new HangmanMessage("", 1, username, "", "", "", "", "", "", null, null);
						//1: check for repeated username
						oos.writeObject(hm1);
						oos.flush();
					
					}
					catch(IOException ioe){
						System.out.println("ioe: "+ioe.getMessage());
					}
					if(!repeatedUsername){
		
						System.out.println("The username you inputted has been used.");
					}else{
						break;
					}
						
				}
				while(repeatedGamename){
					System.out.println("Please enter a unique name for your game");
					String gamename = scanner.nextLine();
					try{
						HangmanMessage hm2 = new HangmanMessage("", 3, gamename, "", "", "", "", "", "", null, null);
						oos.writeObject(hm2);
						oos.flush();
						TimeUnit.MILLISECONDS.sleep(200);
					}catch(IOException ioe){
						System.out.println("ioe: "+ioe.getMessage());
					}catch(InterruptedException ie){
						System.out.println("ie: "+ie);
					}
					if(!repeatedGamename){
						System.out.print("The game name you inputted has been used. ");
					}else{
						
						break;
					}	
				}//while repeatedGamename

				while(!validnumbersize){
					System.out.println("Please enter the number of players (1 - 4) in this game.");
					String in = scanner.nextLine();
					if(isInteger(in)){
						int num = Integer.parseInt(in);
						if(num>=1 && num<=4){
							validnumbersize = true;
							GameSize = in;
							try{
								
								HangmanMessage hm3 = new HangmanMessage(GameName, 5, UserName, GameSize, "", "", "", "", "", null, null);
								oos.writeObject(hm3);
								oos.flush();
								TimeUnit.MILLISECONDS.sleep(200);
								
							}catch(IOException ioe){
								System.out.println("ioe in create game: "+ioe.getMessage());
							}catch(InterruptedException ie){
								System.out.println("ie in create game: "+ie.getMessage());
							}
							break;
						}else{
							System.out.print("Invalid number of players. ");
						}
					}else{
						System.out.print("Invalid number of players. ");
					}
				}//while validnumbersize
				//System.out.println("waiting for nnnn players to join..");
				//give the server a signal to create the object

				//System.out.println(successfulcreated);
				if(successfulcreated){

					if(currentDifference.equals("0")){
						
						System.out.println("Start Game!");
						try{
							
							HangmanMessage hm3 = new HangmanMessage(GameName, 41, UserName, "", "", "", "", "", "", null, null);
							oos.writeObject(hm3);
							oos.flush();
							TimeUnit.MILLISECONDS.sleep(100);
							
						}catch(IOException ioe){
							System.out.println("ioe in create game: "+ioe.getMessage());
						}catch(InterruptedException ie){
							System.out.println("ie in create game: "+ie.getMessage());
						}
						
						
					}else{
						System.out.println("Waiting for "+currentDifference+" players to join...");
					}
					
					
				}
	
				while(true){//for the creator
					
					while(okToSend){
					
						String cop = scanner.nextLine();
						try{
							HangmanMessage hm5 = new HangmanMessage(currGameName, 21, cop, UserName, "", "", "", "", "", null, null);
							oos.writeObject(hm5);
							oos.flush();
							TimeUnit.MILLISECONDS.sleep(40);
						}catch(IOException ioe){
							System.out.println("ioe in create game: "+ioe.getMessage());
						}catch(InterruptedException ie){
							System.out.println("ie in create game: "+ie.getMessage());
						}
						if(endGame){
							break;
						}
						if(!okToSend){
							break;
						}
					}
					//System.out.println("can't send message any more");
					if(endGame){
						break;
					}
					
				}
				System.out.println("end of receiving message");
				this.stop();
				playerClient pc = new playerClient(sk);

			}
			
			
			
			if(Integer.parseInt(finalcommand)==2){
				while(!foundthegame){
					System.out.println("Please enter the name of the game you wish to join.");
					String gamename = scanner.nextLine();
					try{
						HangmanMessage hm4 = new HangmanMessage("", 7, gamename, "", "", "", "", "", "", null, null);
						oos.writeObject(hm4);
						oos.flush();
						TimeUnit.MILLISECONDS.sleep(400);
					}catch(IOException ioe){
						System.out.println("ioe in create game: "+ioe.getMessage());
					}catch(InterruptedException ie){
						System.out.println("ie in create game: "+ie.getMessage());
					}
					if(!foundthegame){
						System.out.println("This game does not exist or has already reached the maximum number of players.");
					}else{
						System.out.println("Congratulations! You have joined "+gamename);
						currGameName = gamename;
						break;
					}
				}
				while(repeatedusernameingame){
					System.out.println("Please enter your username");
					String username = scanner.nextLine();
					try{
						HangmanMessage hm9 = new HangmanMessage(currGameName, 9, username, "", "", "", "", "", "", null, null);
						//1: check for repeated username
						oos.writeObject(hm9);
						oos.flush();
					}catch(IOException ioe){
						System.out.println("ioe: "+ioe.getMessage());
					}
					if(!repeatedusernameingame){
						System.out.println("The username you inputted has been used.");
					}else{
						System.out.println("waiting for other players to join...");
						break;
					}
				}
				while(true){//for the joiner
					while(okToSend){
						String cop = scanner.nextLine();
						try{
							HangmanMessage hm5 = new HangmanMessage(currGameName, 21, cop, UserName, "", "", "", "", "", null, null);
							oos.writeObject(hm5);
							oos.flush();
							TimeUnit.MILLISECONDS.sleep(40);
						}catch(IOException ioe){
							System.out.println("ioe in create game: "+ioe.getMessage());
						}catch(InterruptedException ie){
							System.out.println("ie in create game: "+ie.getMessage());
						}
						if(endGame){
							break;
						}
						if(!okToSend){
							break;
						}
						
					}
					//System.out.println("can't send message any more");
					if(endGame){
						break;
					}
					
				}
				System.out.println("end of receiving message");
				this.stop();
				playerClient pc = new playerClient(sk);
				
			}//command == 2
			

		}catch(IOException ioe){
			System.out.println("ioe in chatClient: "+ioe.getMessage());
		}finally{
			try{
				if(sk!=null){
					sk.close();
				}
				if(scanner!=null){
					scanner.close();
				}
			}catch(IOException ioe){
				System.out.println("ioe in closing: "+ioe.getMessage());
			}
		}
	}
	

	public static boolean isInteger(String str) {
	    try {
	        Integer.parseInt(str);
	        return true;
	    } catch (NumberFormatException nfe) {}
	    return false;
	}
	

	
	public void run(){
		try{
			while(true){
				HangmanMessage hm = (HangmanMessage)ois.readObject();
				int type = hm.getType();
				if(type==2){
					String messa = hm.getContent();
					
					if(messa.equals("no username found")){
						repeatedUsername = false;
						UserName = hm.getResult();
						//System.out.println(UserName);
					}
					if(messa.equals("find this username")){
						repeatedUsername = true;
						
					}
				}
				if(type==4){
		
					String messa = hm.getContent();
					if(messa.equals("no gamename found")){
						repeatedGamename = false;
						GameName = hm.getResult();
						currGameName =  hm.getResult();
					}
					if(messa.equals("find this gamename"));{
						repeatedGamename = true;
					}
				}//type 4
				if(type==6){
					//System.out.println("get the result");
					successfulcreated = true;
					currentDifference = hm.getContent();
				}
				if(type==8){
					String result = hm.getContent();
					if(result.equals("okay")){
						foundthegame = true;
					}
				}
				if(type==10){
					String result = hm.getContent();
					String correctName = hm.getResult();
					if(result.equals("okay")){
						repeatedusernameingame = false;
						UserName = correctName;
					}
				}
				if(type==12){
					//System.out.print("join here");
					String joiningname = hm.getContent();
					String remaining = hm.getResult();
					System.out.println(joiningname+" joined the game. Waiting for "+remaining+" players to join...");
				}
				if(type==42){
					String theWord = hm.getContent();
					printPicture pp = new printPicture(0, "", theWord);
					System.out.println(UserName+", please enter a character or the entire phrase as a guess");
				}
				if(type==14){
					String allmem = hm.getContent();
					String theWord = hm.getResult();
					System.out.println("all players have joined: "+allmem);
					printPicture pp = new printPicture(0, "", theWord);
					String currN = UserName;
					System.out.println(UserName+", please enter a character or the entire phrase as a guess");
				}
				if(type==24){
					String username = hm.getContent();
					String life = currLife;
					//check if life is 7
					String gameIsOver = hm.getGameOver();
					if(gameIsOver.equals("true")){// game over
						endGame = true;
						String winType = hm.getWinType();
						if(winType.equals("3")){
							String winnerName = hm.getPlayerList().get(0);
							if(winnerName.equals(UserName)){
								System.out.println(username+" completed their hangman. They have been elimated :/");
								String wrongList = hm.getWrongList();
								String afterEn = hm.getEncrypt();
								HashMap<String, Integer>ree = hm.getLifeTable();
								int thelife = ree.get(UserName);
								System.out.println(UserName+" "+thelife);
								printPicture pp = new printPicture(Integer.parseInt(currLife), wrongList, afterEn);
								System.out.println("All other players have been eliminated. You win by default! Game over.");
							}else{
								System.out.println("All other players have been eliminated."+ winnerName+" win by default! Game over.");
							}
							
						}else{
							if(username.equals(UserName)){
								String re = hm.getGameName();
								
								
								if(winType.equals("1")){
									System.out.print("You guessed the last character of the phrase. ");
								}
								if(winType.equals("2")){
									System.out.println(re);
								}
								
								System.out.println("You win! Game over.");
								String wrongList = hm.getWrongList();
								String afterEn = hm.getEncrypt();
								HashMap<String, Integer>ree = hm.getLifeTable();
								int thelife = ree.get(UserName);
								//System.out.println(UserName+" "+thelife);
								printPicture pp = new printPicture(Integer.parseInt(currLife), wrongList, afterEn);
							}else{
								//String winType = hm.getWinType();
								if(winType.equals("1")){
									ArrayList<String> pl = hm.getPlayerList();
									System.out.print(username+" guessed the last character of the phrase. ");
									for(int k=0; k<pl.size(); k++){
										if(!pl.get(k).equals(username)){
											if(pl.get(k).equals(UserName)){
												System.out.print("you");
											}else{
												System.out.print(pl.get(k));
											}								
											if(k<pl.size()-2){
												System.out.print(" and ");
											}
										}
										
									}
									System.out.println(" lose:(. Game over.");
								}
								if(winType.equals("2")){
									String theThing = hm.getResult();
									System.out.println(username+" guessed '"+theThing+"'");
									System.out.print(username+" wins!");
									ArrayList<String> pl = hm.getPlayerList();
									for(int k=0; k<pl.size(); k++){
										if(!pl.get(k).equals(username)){
											if(pl.get(k).equals(UserName)){
												System.out.print("you");
											}else{
												System.out.print(pl.get(k));
											}
											if(k<pl.size()-2){
												System.out.print(" and ");
											}
										}
										
									}
									System.out.println(" lose:(. Game over.");
								}
							}
							
						}


					}else{//game is not over
						String re = hm.getGameName();
						life = hm.getLife();
						if(username.equals(UserName)){
							System.out.println(re);
							life = hm.getLife();
							currLife = life;
							
						}else{
							String theThing = hm.getResult();
							System.out.println(username+" guessed '"+theThing+"'");
						}
						String wrongList = hm.getWrongList();
						String afterEn = hm.getEncrypt();
						HashMap<String, Integer>ree = hm.getLifeTable();
						int thelife = ree.get(UserName);
						//System.out.println(ree);
						//System.out.println(UserName+" "+thelife);
						printPicture pp = new printPicture(Integer.parseInt(currLife), wrongList, afterEn);
						
						if(life.equals("7")){
								if(username.equals(UserName)){
									okToSend = false;
									System.out.println("Your hangman has been completed. You lose :(");
									System.out.println("You have been eliminated. You many only spectate for the rest of the game. ");
									
									
								}else{
									
									System.out.println(username+" completed their hangman. They have been elimated :/");
									System.out.println(UserName+", please enter a character or the entire phrase as a guess");
								}
								
							}else{
								
								System.out.println(UserName+", please enter a character or the entire phrase as a guess");
						}
						
						
						
					}
				}
			}
		}catch(ClassNotFoundException cnfe){
				System.out.println("cnfe: "+cnfe.getMessage());
			}catch(IOException ioe){
				System.out.println("ioe here: "+ioe.getMessage());
			}
		
}


	public static void main(String args[]){
		Socket s = null;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Welcome to Cineman!");
		System.out.println("");
		while(true){
			System.out.println("Please enter the ipaddress");
			String ip  = scanner.nextLine();
			validipaddress = ip;
			System.out.println("Please enter the port");
			String input = scanner.nextLine();

			boolean validPort = false;
			while(!validPort){
				if(isInteger(input)){
					int portNumber = Integer.parseInt(input);
					if(portNumber>=0 && portNumber<=65535){
						validPort = true;
						validportname = Integer.parseInt(input);
						break;
					}
				}
				System.out.println("Invalid port. Please enter the port to host the server");
				input = scanner.nextLine();
			}

			//check if the portname and ipaddress can be connected
			try{
			    s = new Socket(validipaddress, validportname);
				System.out.println("Successfully build a client");
				break;
				
			}catch(IOException ioe){
				System.out.println("Unable to connect ot server with provided fields");
			}
		}
		//finally
		System.out.println("Congratulations! You have connected to the Cineman server!");

		new playerClient(s);
	}
}
