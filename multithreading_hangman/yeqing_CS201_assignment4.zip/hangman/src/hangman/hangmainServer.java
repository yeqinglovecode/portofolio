package hangman;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



public class hangmainServer {
	public Vector<ServerThread>serverThreads;
	private static int validportname;
	private static String validaddress = "";
	public ArrayList<HangmanGame>aListOfGame;
	//public String theWord = "The Count of Monte Cristo";
	public static ArrayList<String>wordBank;
	public String theWord = "cat";
	public String afterEncrypt="";
	
	
	public ArrayList<HangmanGame> getGames(){
		return aListOfGame;
	}
	
	public ServerThread findAThread(String gameName, String username){
		for(int i=0; i<this.serverThreads.size(); i++){
			if(gameName.equals(this.serverThreads.get(i).gameName)){
				if(username.equals(this.serverThreads.get(i).currUsername)){
					return this.serverThreads.get(i);
				}
			}
		}
		return null;
	}
	
	public ArrayList<ServerThread>findByGameName(String gameName){
		ArrayList<ServerThread>result = new ArrayList<ServerThread>();
		for(int i=0; i<this.serverThreads.size(); i++){
			if(gameName.equals(this.serverThreads.get(i).getName())){
				result.add(this.serverThreads.get(i));
			}
		}
		return result;
	}
	
	public hangmainServer(int port){
		ServerSocket ss = null;
		serverThreads = new Vector<ServerThread>();
		aListOfGame = new ArrayList<HangmanGame>();
		wordBank = new ArrayList<String>();
		try{
			ss = new ServerSocket(port);
			System.out.println("Server started!");
			try{
				readFile(validaddress);
			}catch(FileNotFoundException fnfe){
				System.out.println("file not found: "+fnfe.getMessage());
			}
			while(true){
				//System.out.println("waiting for connection...");
				Socket s = ss.accept();
				//continue waiting a client connecting to us
				//System.out.println("Connection from "+s.getInetAddress());
				ServerThread st = new ServerThread(s, this);
				serverThreads.add(st);
				//System.out.println(serverThreads.size());
			}
		}catch(IOException ioe){
			System.out.println("ioe in hangmanServer: "+ioe.getMessage());
		}finally{
			if(ss!=null){
				try{
					ss.close();
				}catch(IOException ioe){
					System.out.println("ioe closing ss: "+ioe.getMessage());
				}
			}
		}
	}
	
	
	/*
	 * Utility function
	 */
	public static boolean isInteger(String str) {
	    try {
	        Integer.parseInt(str);
	        return true;
	    } catch (NumberFormatException nfe) {}
	    return false;
	}
	
	public static int setUpGame(Scanner scanner) throws IOException{
		System.out.println("Please enter the port to host the server");
		String input = scanner.nextLine();
		boolean validPort = false;
		while(!validPort){
			if(isInteger(input)){
				int portNumber = Integer.parseInt(input);
				if(portNumber>=0 && portNumber<=65535){
					validPort = true;
					validportname = Integer.parseInt(input);
					break;
				}
			}
			System.out.println("Invalid port. Please enter the port to host the server");
			input = scanner.nextLine();
		}
		System.out.println("Please enter the path to the xml file used for the game phrases");
		String address = scanner.nextLine();
		boolean validAddress = false;
		while(!validAddress){
			if(address.endsWith(".xml")){
				validAddress = true;
				break;
			}
			System.out.println("Invalid address. Please enter the path to the xml file used for the game phrases");
			address = scanner.nextLine();
		}
		validaddress = address;		
		return 1;
	}
	
	public void sendMessageToSomeClients(ArrayList<location>list,HangmanMessage hm){
		for(int i=0; i<list.size(); i++){
			ServerThread st = findAThread(list.get(i).gameName, list.get(i).userName);
			st.sendMessage(hm);	
		}
	}
	public void sendMessageToPeopleInOneGame(String gameName, HangmanMessage hm){
		//System.out.println("here");
		//System.out.println(this.serverThreads.size());
		for(int i=0; i<this.serverThreads.size(); i++){
			if(gameName.equals(this.serverThreads.get(i).gameName)){
				//System.out.println("sent");
				this.serverThreads.get(i).sendMessage(hm);
			}
		}
	}
	
	//parseFile function
	public static String readFile(String fileName) throws FileNotFoundException{
		String error = "nothing";
		
		try{
			File inputFile = new File(fileName);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(inputFile);
			doc.getDocumentElement().normalize();
			
		
			
			NodeList outerMovieList = doc.getElementsByTagName("movies");
			for(int index=0; index<outerMovieList.getLength(); index++){
				Node outerMovieNode = outerMovieList.item(index);
				if(outerMovieNode.getNodeType() == Node.ELEMENT_NODE){
					Element outerMovieElement = (Element)outerMovieNode;
					NodeList movieList = outerMovieElement.getElementsByTagName("movie");
					if(movieList.getLength()==0){
						error = "There are no movie objects found under <movies> tag";	
					}else{
						for(int i=0; i<movieList.getLength(); i++){
							Node movieNode = movieList.item(i);
							if(movieNode.getNodeType() == Node.ELEMENT_NODE){
								Element eElement = (Element) movieNode;
								
								//movie newMovie = new movie(eElement.getElementsByTagName("title").item(0).getTextContent());
								wordBank.add(eElement.getElementsByTagName("title").item(0).getTextContent());
								//newMovie.setDirector(eElement.getElementsByTagName("director").item(0).getTextContent());
								//newMovie.setPoster(eElement.getElementsByTagName("image").item(0).getTextContent());
								NodeList writerList = eElement.getElementsByTagName("writer");
								for(int j=0; j<writerList.getLength(); j++){
									Node writerNode = writerList.item(j);
									wordBank.add(writerNode.getTextContent());
								}
							
								

								NodeList outerActorList = eElement.getElementsByTagName("actors");
								
								for(int ind=0; ind<outerActorList.getLength(); ind++){
									Node outerActorNode = outerActorList.item(ind);
									if(outerActorNode.getNodeType() == Node.ELEMENT_NODE){
										Element outerActorElement = (Element)outerActorNode;
										NodeList actorList = outerActorElement.getElementsByTagName("actor");
										
										for(int m=0; m<actorList.getLength(); m++){
											Node actorNode = actorList.item(m);
											if(actorNode.getNodeType() == Node.ELEMENT_NODE){
												Element actorElement = (Element) actorNode;
												//actor newActor = new actor(actorElement.getElementsByTagName("image").item(0).getTextContent());
												String fname = actorElement.getElementsByTagName("fname").item(0).getTextContent();
												String lname = actorElement.getElementsByTagName("lname").item(0).getTextContent();
												//newActor.createFullName();
												String fullname = fname + " " + lname;
												wordBank.add(fullname);
											}//if
										}//for
									}//if
								}//for outer
							
							}
						}//for loop for movie
					}
				}
			}
		}catch(FileNotFoundException fnfe){
			System.out.println(fnfe.getMessage());
			error = "No file found.";
		}catch(IOException ioe){
			System.out.println(ioe.getMessage());
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			return error;
		}
	}

	
	public static void main (String args[]){
		//encrypt();
		Scanner in = new Scanner(System.in);
		boolean success = false;
		while(!success){
			try{
				int integer = setUpGame(in);
				if(integer==1){
					success = true;
					new hangmainServer(validportname);

					
				}
			}catch(IOException ioe){
				System.out.println("IOException: "+ioe.getMessage());
			}
		}
		//after setting up the port and address

				
		
	}
}
