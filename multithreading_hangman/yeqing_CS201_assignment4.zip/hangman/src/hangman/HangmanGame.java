package hangman;

import java.util.ArrayList;
import java.util.HashMap;

public class HangmanGame {
	private static boolean ready;
	private String creator;
	private int numOfPlayers;
	private String gameName;
	private ArrayList<String>playerNameList;
	private int difference;
	public String theWord;
	public String afterEncrypt;
	public HashMap<String, Integer>lifeRecord;
	public String wrongGussedList;
	public boolean GameOver;
	public HangmanGame(String gameName, int numofplayers, String creator){
		ready = false;
		lifeRecord = new HashMap<String, Integer>();
		this.gameName = gameName;
		this.creator = creator;
		this.numOfPlayers = numofplayers;
		playerNameList = new ArrayList<String>();
		playerNameList.add(creator);
		lifeRecord.put(creator, 0);
		wrongGussedList = "";
		GameOver = false;
		if(numOfPlayers==1){
			this.ready = true;
			difference = 0;
		}
		if(!ready){
			calculateDifference();
		}
	}
	public void calculateDifference(){
		difference = numOfPlayers - playerNameList.size();
		if(difference==0){
			ready = true;
		}
	}
	public int getDifference(){
		return difference;
	}
	public boolean getReady(){
		return ready;
	}
	public void setReady(boolean state){
		ready = state;
	}
	public ArrayList<String> getNameList(){
		return playerNameList;
	}
	public void addPlayer(String name){
		playerNameList.add(name);
	}
	public String getName(){
		return gameName;
	}
	public void setDifference(int d){
		this.difference = d;
	}
	public String getCreator(){
		return creator;
	}
	public void setWord(String word){
		theWord = word;
		theWord = theWord.toLowerCase();
		afterEncrypt = encrypt(theWord);
	}
	public String encrypt(String the){
		String after="";
		for(int i=0; i<the.length(); i++){
			//System.out.println(theWord.charAt(i));
			if(the.charAt(i)==' '){
				after+=" ";
			}else{
				after+="_";
			}
		}
		//System.out.println(after);
		//afterEncrypt = after;
		return after;
	}
	public void createHashMap(){
		for(int i=0; i<playerNameList.size(); i++){
			lifeRecord.put(playerNameList.get(i), 0);
		}
	}
	/*
	 * Before call decreaseALife, you should check whether the life is aleady 0
	 */
	public void decreaseALife(String name){
		lifeRecord.put(name, lifeRecord.get(name)+1);
	}
	public void updateAfterEncrypt(String a){
		char letter = a.charAt(0);
		char[] ch = afterEncrypt.toCharArray();
		for(int i=0; i<theWord.length(); i++){
			if(theWord.charAt(i)==letter){
				ch[i] = theWord.charAt(i);
			}
		}
		afterEncrypt = new String(ch);
		if(afterEncrypt.equals(theWord)){
			GameOver = true;
		}
		//System.out.println(afterEncrypt);
		
	}
	public int getLife(String name){
		int value = lifeRecord.get(name);
		return value;
	}
	public void appendWrongGuess(String wrongGuess){
		wrongGussedList+=wrongGuess;
	}
}
