package hangman;

public class location {
	public String gameName;
	public String userName;
	public location(String gn, String un){
		gameName = gn;
		userName = un;
	}
}
