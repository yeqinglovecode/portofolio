package hangman;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class HangmanMessage implements Serializable{
	public static final long serialVersionUID = 1;
	private String gameName;
	private int type;
	private String content;
	private String result;
	private String WrongList;
	private String Life;
	private String Encrypt;
	private String gameover;
	private String winType;
	private ArrayList<String>pl;
	private HashMap<String, Integer>lt;
	public HangmanMessage(String gameName, int type, String content, String result, String WrongList, String Life, String Encrypt, String Gameover, String winType, ArrayList<String>players, HashMap<String, Integer>lifeTable){
		this.gameName = gameName;
		this.type = type;
		this.content = content;
		this.result = result;
		this.WrongList = WrongList;
		this.Life = Life;
		this.Encrypt = Encrypt;
		this.gameover = Gameover;
		this.winType = winType;
		pl = players;
		lt = lifeTable;
	}
	public String getGameName(){
		return gameName;
	}
	public int getType(){
		return type;
	}
	public String getContent(){
		return content;
	}
	public String getResult(){
		return result;
	}
	public String getWrongList(){
		return WrongList;
	}
	public String getLife(){
		return Life;
	}
	public String getEncrypt(){
		return Encrypt;
	}
	public String getGameOver(){
		return gameover;
	}
	public String getWinType(){
		return winType;
	}
	public ArrayList<String>getPlayerList(){
		return pl;
	}
	public HashMap<String, Integer>getLifeTable(){
		return lt;
	}

}
